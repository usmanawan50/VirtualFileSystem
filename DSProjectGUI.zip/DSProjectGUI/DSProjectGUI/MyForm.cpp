// entry point for project

#include "MyForm.h" 

using namespace VFS_GUI;
using namespace System;
using namespace System::Windows::Forms;


[STAThreadAttribute]           // essential for Windows Forms applications to run in a Single Threaded Apartment model.
int main(array<String^>^ args) // standard signature for a .NET application entry point.
{
    Application::EnableVisualStyles();

    // sets default text rendering engine for the application to GDI+.
    Application::SetCompatibleTextRenderingDefault(false);

    // create main window
    MyForm^ form = gcnew MyForm();

    // run project
    Application::Run(form);

    return 0;
}
