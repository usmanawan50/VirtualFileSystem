#pragma once

#include "VirtualFileSystem.h"
#include <msclr/marshal_cppstd.h> // For converting System::String to std::string and vice-versa

namespace VFS_GUI { 

    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;
    using namespace System::IO;

    public ref class MyForm : public System::Windows::Forms::Form
    {
    public:
        MyForm(void)
        {
            InitializeComponent();
            // initialize VirtualFileSystem instance
            vfs = new VirtualFileSystem(); 
            RefreshFileList();
            UpdateDiskUsageLabel();
        }

    protected:
        ~MyForm()
        {
            if (components)
            {
                delete components;
            }
            delete vfs; 
        }

    private:
        // GUI components
        System::Windows::Forms::ListBox^ listBoxVFSFiles;
        System::Windows::Forms::Button^ btnCreateFile;
        System::Windows::Forms::Button^ btnViewFile;
        System::Windows::Forms::Button^ btnModifyFile;
        System::Windows::Forms::Button^ btnDeleteFile;
        System::Windows::Forms::Button^ btnCopyFromWin;
        System::Windows::Forms::Button^ btnCopyToWin;
        System::Windows::Forms::RichTextBox^ richTextBoxContent;
        System::Windows::Forms::Label^ labelFileName;
        System::Windows::Forms::TextBox^ textBoxFileName;
        System::Windows::Forms::Label^ labelDiskUsage;
        System::Windows::Forms::Button^ btnSaveChanges;   // for modify/create
        System::Windows::Forms::Button^ btnNewFileEditor; // To bring up create mode


        private: System::Windows::Forms::Label^ labelContent;
        private: System::Windows::Forms::GroupBox^ groupBoxFileOps;
        private: System::Windows::Forms::GroupBox^ groupBoxEditor;
        private: System::Windows::Forms::Label^ labelStatus;

        VirtualFileSystem* vfs;
        bool isCreatingNewFile; // flag to manage editor mode


        private: System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
           void InitializeComponent(void)
           {
               this->listBoxVFSFiles = (gcnew System::Windows::Forms::ListBox());
               this->btnCreateFile = (gcnew System::Windows::Forms::Button());
               this->btnViewFile = (gcnew System::Windows::Forms::Button());
               this->btnModifyFile = (gcnew System::Windows::Forms::Button());
               this->btnDeleteFile = (gcnew System::Windows::Forms::Button());
               this->btnCopyFromWin = (gcnew System::Windows::Forms::Button());
               this->btnCopyToWin = (gcnew System::Windows::Forms::Button());
               this->richTextBoxContent = (gcnew System::Windows::Forms::RichTextBox());
               this->labelFileName = (gcnew System::Windows::Forms::Label());
               this->textBoxFileName = (gcnew System::Windows::Forms::TextBox());
               this->labelDiskUsage = (gcnew System::Windows::Forms::Label());
               this->btnSaveChanges = (gcnew System::Windows::Forms::Button());
               this->labelContent = (gcnew System::Windows::Forms::Label());
               this->groupBoxFileOps = (gcnew System::Windows::Forms::GroupBox());
               this->btnNewFileEditor = (gcnew System::Windows::Forms::Button());
               this->groupBoxEditor = (gcnew System::Windows::Forms::GroupBox());
               this->labelStatus = (gcnew System::Windows::Forms::Label());
               this->groupBoxFileOps->SuspendLayout();
               this->groupBoxEditor->SuspendLayout();
               this->SuspendLayout();
               // 
               // listBoxVFSFiles
               // 
               this->listBoxVFSFiles->FormattingEnabled = true;
               this->listBoxVFSFiles->ItemHeight = 16;
               this->listBoxVFSFiles->Location = System::Drawing::Point(18, 28);
               this->listBoxVFSFiles->Margin = System::Windows::Forms::Padding(4);
               this->listBoxVFSFiles->Name = L"listBoxVFSFiles";
               this->listBoxVFSFiles->Size = System::Drawing::Size(280, 212);
               this->listBoxVFSFiles->TabIndex = 0;
               this->listBoxVFSFiles->SelectedIndexChanged += gcnew System::EventHandler(this, &MyForm::listBoxVFSFiles_SelectedIndexChanged);
               // 
               // btnCreateFile
               // 
               this->btnCreateFile->Location = System::Drawing::Point(0, 0);
               this->btnCreateFile->Name = L"btnCreateFile";
               this->btnCreateFile->Size = System::Drawing::Size(75, 23);
               this->btnCreateFile->TabIndex = 0;
               // 
               // btnViewFile
               // 
               this->btnViewFile->Location = System::Drawing::Point(160, 30);
               this->btnViewFile->Margin = System::Windows::Forms::Padding(4);
               this->btnViewFile->Name = L"btnViewFile";
               this->btnViewFile->Size = System::Drawing::Size(120, 28);
               this->btnViewFile->TabIndex = 2;
               this->btnViewFile->Text = L"View Selected";
               this->btnViewFile->UseVisualStyleBackColor = true;
               this->btnViewFile->Click += gcnew System::EventHandler(this, &MyForm::btnViewFile_Click);
               // 
               // btnModifyFile
               // 
               this->btnModifyFile->Location = System::Drawing::Point(20, 70);
               this->btnModifyFile->Margin = System::Windows::Forms::Padding(4);
               this->btnModifyFile->Name = L"btnModifyFile";
               this->btnModifyFile->Size = System::Drawing::Size(120, 28);
               this->btnModifyFile->TabIndex = 3;
               this->btnModifyFile->Text = L"Modify Selected";
               this->btnModifyFile->UseVisualStyleBackColor = true;
               this->btnModifyFile->Click += gcnew System::EventHandler(this, &MyForm::btnModifyFile_Click);
               // 
               // btnDeleteFile
               // 
               this->btnDeleteFile->Location = System::Drawing::Point(160, 70);
               this->btnDeleteFile->Margin = System::Windows::Forms::Padding(4);
               this->btnDeleteFile->Name = L"btnDeleteFile";
               this->btnDeleteFile->Size = System::Drawing::Size(120, 28);
               this->btnDeleteFile->TabIndex = 4;
               this->btnDeleteFile->Text = L"Delete Selected";
               this->btnDeleteFile->UseVisualStyleBackColor = true;
               this->btnDeleteFile->Click += gcnew System::EventHandler(this, &MyForm::btnDeleteFile_Click);
               // 
               // btnCopyFromWin
               // 
               this->btnCopyFromWin->Location = System::Drawing::Point(20, 110);
               this->btnCopyFromWin->Margin = System::Windows::Forms::Padding(4);
               this->btnCopyFromWin->Name = L"btnCopyFromWin";
               this->btnCopyFromWin->Size = System::Drawing::Size(260, 28);
               this->btnCopyFromWin->TabIndex = 5;
               this->btnCopyFromWin->Text = L"Copy From Windows...";
               this->btnCopyFromWin->UseVisualStyleBackColor = true;
               this->btnCopyFromWin->Click += gcnew System::EventHandler(this, &MyForm::btnCopyFromWin_Click);
               // 
               // btnCopyToWin
               // 
               this->btnCopyToWin->Location = System::Drawing::Point(20, 150);
               this->btnCopyToWin->Margin = System::Windows::Forms::Padding(4);
               this->btnCopyToWin->Name = L"btnCopyToWin";
               this->btnCopyToWin->Size = System::Drawing::Size(260, 28);
               this->btnCopyToWin->TabIndex = 6;
               this->btnCopyToWin->Text = L"Copy To Windows...";
               this->btnCopyToWin->UseVisualStyleBackColor = true;
               this->btnCopyToWin->Click += gcnew System::EventHandler(this, &MyForm::btnCopyToWin_Click);
               // 
               // richTextBoxContent
               // 
               this->richTextBoxContent->AcceptsTab = true;
               this->richTextBoxContent->Location = System::Drawing::Point(15, 85);
               this->richTextBoxContent->Margin = System::Windows::Forms::Padding(4);
               this->richTextBoxContent->Name = L"richTextBoxContent";
               this->richTextBoxContent->Size = System::Drawing::Size(430, 220);
               this->richTextBoxContent->TabIndex = 7;
               this->richTextBoxContent->Text = L"";
               // 
               // labelFileName
               // 
               this->labelFileName->AutoSize = true;
               this->labelFileName->Location = System::Drawing::Point(12, 30);
               this->labelFileName->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
               this->labelFileName->Name = L"labelFileName";
               this->labelFileName->Size = System::Drawing::Size(72, 16);
               this->labelFileName->TabIndex = 8;
               this->labelFileName->Text = L"File Name:";
               // 
               // textBoxFileName
               // 
               this->textBoxFileName->Location = System::Drawing::Point(90, 27);
               this->textBoxFileName->Margin = System::Windows::Forms::Padding(4);
               this->textBoxFileName->Name = L"textBoxFileName";
               this->textBoxFileName->Size = System::Drawing::Size(260, 22);
               this->textBoxFileName->TabIndex = 9;
               // 
               // labelDiskUsage
               // 
               this->labelDiskUsage->AutoSize = true;
               this->labelDiskUsage->Location = System::Drawing::Point(20, 250);
               this->labelDiskUsage->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
               this->labelDiskUsage->Name = L"labelDiskUsage";
               this->labelDiskUsage->Size = System::Drawing::Size(103, 16);
               this->labelDiskUsage->TabIndex = 10;
               this->labelDiskUsage->Text = L"Disk Usage: 0%";
               // 
               // btnSaveChanges
               // 
               this->btnSaveChanges->Location = System::Drawing::Point(358, 25);
               this->btnSaveChanges->Margin = System::Windows::Forms::Padding(4);
               this->btnSaveChanges->Name = L"btnSaveChanges";
               this->btnSaveChanges->Size = System::Drawing::Size(88, 28);
               this->btnSaveChanges->TabIndex = 11;
               this->btnSaveChanges->Text = L"Save";
               this->btnSaveChanges->UseVisualStyleBackColor = true;
               this->btnSaveChanges->Click += gcnew System::EventHandler(this, &MyForm::btnSaveChanges_Click);
               // 
               // labelContent
               // 
               this->labelContent->AutoSize = true;
               this->labelContent->Location = System::Drawing::Point(12, 65);
               this->labelContent->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
               this->labelContent->Name = L"labelContent";
               this->labelContent->Size = System::Drawing::Size(80, 16);
               this->labelContent->TabIndex = 12;
               this->labelContent->Text = L"File Content:";
               // 
               // groupBoxFileOps
               // 
               this->groupBoxFileOps->Controls->Add(this->btnNewFileEditor);
               this->groupBoxFileOps->Controls->Add(this->btnViewFile);
               this->groupBoxFileOps->Controls->Add(this->btnModifyFile);
               this->groupBoxFileOps->Controls->Add(this->btnDeleteFile);
               this->groupBoxFileOps->Controls->Add(this->btnCopyFromWin);
               this->groupBoxFileOps->Controls->Add(this->btnCopyToWin);
               this->groupBoxFileOps->Location = System::Drawing::Point(18, 280);
               this->groupBoxFileOps->Name = L"groupBoxFileOps";
               this->groupBoxFileOps->Size = System::Drawing::Size(290, 195);
               this->groupBoxFileOps->TabIndex = 13;
               this->groupBoxFileOps->TabStop = false;
               this->groupBoxFileOps->Text = L"File Operations";
               // 
               // btnNewFileEditor
               // 
               this->btnNewFileEditor->Location = System::Drawing::Point(20, 30);
               this->btnNewFileEditor->Margin = System::Windows::Forms::Padding(4);
               this->btnNewFileEditor->Name = L"btnNewFileEditor";
               this->btnNewFileEditor->Size = System::Drawing::Size(120, 28);
               this->btnNewFileEditor->TabIndex = 1;
               this->btnNewFileEditor->Text = L"New File";
               this->btnNewFileEditor->UseVisualStyleBackColor = true;
               this->btnNewFileEditor->Click += gcnew System::EventHandler(this, &MyForm::btnNewFileEditor_Click);
               // 
               // groupBoxEditor
               // 
               this->groupBoxEditor->Controls->Add(this->labelFileName);
               this->groupBoxEditor->Controls->Add(this->textBoxFileName);
               this->groupBoxEditor->Controls->Add(this->labelContent);
               this->groupBoxEditor->Controls->Add(this->richTextBoxContent);
               this->groupBoxEditor->Controls->Add(this->btnSaveChanges);
               this->groupBoxEditor->Location = System::Drawing::Point(330, 28);
               this->groupBoxEditor->Name = L"groupBoxEditor";
               this->groupBoxEditor->Size = System::Drawing::Size(460, 320);
               this->groupBoxEditor->TabIndex = 14;
               this->groupBoxEditor->TabStop = false;
               this->groupBoxEditor->Text = L"Editor / Viewer";
               // 
               // labelStatus
               // 
               this->labelStatus->Anchor = static_cast<System::Windows::Forms::AnchorStyles>(((System::Windows::Forms::AnchorStyles::Bottom | System::Windows::Forms::AnchorStyles::Left)
                   | System::Windows::Forms::AnchorStyles::Right));
               this->labelStatus->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
               this->labelStatus->Location = System::Drawing::Point(12, 490);
               this->labelStatus->Name = L"labelStatus";
               this->labelStatus->Size = System::Drawing::Size(776, 23);
               this->labelStatus->TabIndex = 15;
               this->labelStatus->Text = L"Status: Ready";
               this->labelStatus->TextAlign = System::Drawing::ContentAlignment::MiddleLeft;
               // 
               // MyForm
               // 
               this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
               this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
               this->ClientSize = System::Drawing::Size(800, 525);
               this->Controls->Add(this->labelStatus);
               this->Controls->Add(this->groupBoxEditor);
               this->Controls->Add(this->groupBoxFileOps);
               this->Controls->Add(this->labelDiskUsage);
               this->Controls->Add(this->listBoxVFSFiles);
               this->Margin = System::Windows::Forms::Padding(4);
               this->Name = L"MyForm";
               this->Text = L"Virtual File System GUI";
               this->groupBoxFileOps->ResumeLayout(false);
               this->groupBoxEditor->ResumeLayout(false);
               this->groupBoxEditor->PerformLayout();
               this->ResumeLayout(false);
               this->PerformLayout();

           }
#pragma endregion

    private:
        // helper methods
        void RefreshFileList() {
            listBoxVFSFiles->Items->Clear();
            std::vector<std::pair<std::string, size_t>> files = vfs->listFiles();
            for (const auto& p : files) {
                String^ displayItem = msclr::interop::marshal_as<String^>(p.first) +
                    " (" + p.second.ToString() + " bytes)";
                listBoxVFSFiles->Items->Add(displayItem);
            }
            if (listBoxVFSFiles->Items->Count > 0) {
                listBoxVFSFiles->SelectedIndex = 0;
            }
            else {
                ClearEditor(); // clear editor if no files
            }
            UpdateDiskUsageLabel();
        }

        void UpdateDiskUsageLabel() {
            double usage = vfs->usagePercent() * 100.0;
            labelDiskUsage->Text = String::Format("Disk Usage: {0:F2}%", usage);
        }

        void ClearEditor() {
            textBoxFileName->Text = "";
            richTextBoxContent->Text = "";
            textBoxFileName->ReadOnly = false; // default for new file
        }

        void ShowStatus(String^ message, bool isError) {
            labelStatus->Text = "Status: " + message;
            labelStatus->ForeColor = isError ? Color::Red : Color::Green;
        }

        // event handlers
        System::Void btnNewFileEditor_Click(System::Object^ sender, System::EventArgs^ e) {
            isCreatingNewFile = true;
            ClearEditor();
            textBoxFileName->Focus();
            groupBoxEditor->Text = "Create New File";
            ShowStatus("Enter new filename and content.", false);
        }

        System::Void btnSaveChanges_Click(System::Object^ sender, System::EventArgs^ e) {
            String^ fileNameSys = textBoxFileName->Text->Trim();
            String^ contentSys = richTextBoxContent->Text;

            if (String::IsNullOrEmpty(fileNameSys)) {
                MessageBox::Show("File name cannot be empty.", "Input Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
                ShowStatus("Error: File name empty.", true);
                return;
            }

            std::string fileNameStd = msclr::interop::marshal_as<std::string>(fileNameSys);
            std::string contentStd = msclr::interop::marshal_as<std::string>(contentSys);
            std::string resultStd;

            if (isCreatingNewFile) {
                resultStd = vfs->createFile(fileNameStd, contentStd);
            }
            else { // modifying existing file
                resultStd = vfs->modifyFile(fileNameStd, contentStd);
            }

            String^ resultSys = msclr::interop::marshal_as<String^>(resultStd);
            bool errorOccurred = resultStd.rfind("Error:", 0) == 0;
            MessageBoxIcon icon = errorOccurred ? MessageBoxIcon::Error : MessageBoxIcon::Information;
            MessageBox::Show(resultSys, isCreatingNewFile ? "Create File" : "Modify File", MessageBoxButtons::OK, icon);
            ShowStatus(resultSys, errorOccurred);

            if (!errorOccurred) {
                RefreshFileList();
                // if creating, select the new file
                if (isCreatingNewFile) {
                    for (int i = 0; i < listBoxVFSFiles->Items->Count; ++i) {
                        String^ itemText = listBoxVFSFiles->Items[i]->ToString();
                        if (itemText->StartsWith(fileNameSys)) {
                            listBoxVFSFiles->SelectedIndex = i;
                            break;
                        }
                    }
                }
                isCreatingNewFile = false; // reset flag
                groupBoxEditor->Text = "Editor / Viewer";
            }
        }

        System::Void btnViewFile_Click(System::Object^ sender, System::EventArgs^ e) {
            if (listBoxVFSFiles->SelectedItem == nullptr) {
                MessageBox::Show("Please select a file to view.", "Selection Error", MessageBoxButtons::OK, MessageBoxIcon::Warning);
                ShowStatus("Select a file to view.", true);
                return;
            }
            isCreatingNewFile = false; // not creating

            String^ selectedItemSys = listBoxVFSFiles->SelectedItem->ToString();
            // Extract filename (name before " (size bytes)")
            int parenIndex = selectedItemSys->LastIndexOf(" (");
            if (parenIndex == -1) {
                MessageBox::Show("Invalid file entry format in list.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
                ShowStatus("Error: Invalid file entry format.", true);
                return;
            }
            String^ fileNameSys = selectedItemSys->Substring(0, parenIndex);

            std::string fileNameStd = msclr::interop::marshal_as<std::string>(fileNameSys);
            std::string contentStd = vfs->viewFile(fileNameStd);
            String^ contentSys = msclr::interop::marshal_as<String^>(contentStd);

            textBoxFileName->Text = fileNameSys;
            textBoxFileName->ReadOnly = true; // Cannot change name when viewing
            richTextBoxContent->Text = contentSys;
            richTextBoxContent->ReadOnly = true; // View only
            groupBoxEditor->Text = "View File: " + fileNameSys;
            if (contentStd.rfind("Error:", 0) == 0) {
                ShowStatus(contentSys, true);
            }
            else {
                ShowStatus("Viewing file: " + fileNameSys, false);
            }
        }

        System::Void btnModifyFile_Click(System::Object^ sender, System::EventArgs^ e) {
            if (listBoxVFSFiles->SelectedItem == nullptr) {
                MessageBox::Show("Please select a file to modify.", "Selection Error", MessageBoxButtons::OK, MessageBoxIcon::Warning);
                ShowStatus("Select a file to modify.", true);
                return;
            }
            isCreatingNewFile = false; // Modifying existing

            String^ selectedItemSys = listBoxVFSFiles->SelectedItem->ToString();
            int parenIndex = selectedItemSys->LastIndexOf(" (");
            if (parenIndex == -1) {
                MessageBox::Show("Invalid file entry format in list.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
                ShowStatus("Error: Invalid file entry format.", true);
                return;
            }
            String^ fileNameSys = selectedItemSys->Substring(0, parenIndex);

            std::string fileNameStd = msclr::interop::marshal_as<std::string>(fileNameSys);
            std::string contentStd = vfs->viewFile(fileNameStd); // get current content to populate editor

            if (contentStd.rfind("Error:", 0) == 0) { // check if viewFile had an error
                String^ errorMsg = msclr::interop::marshal_as<String^>(contentStd);
                MessageBox::Show("Could not load file for modification: " + errorMsg, "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
                ShowStatus("Error loading for modify: " + errorMsg, true);
                return;
            }
            String^ contentSys = msclr::interop::marshal_as<String^>(contentStd);

            textBoxFileName->Text = fileNameSys;
            textBoxFileName->ReadOnly = true; // cannot change name during modify via this button
            richTextBoxContent->Text = contentSys;
            richTextBoxContent->ReadOnly = false; // allow editing
            groupBoxEditor->Text = "Modify File: " + fileNameSys;
            ShowStatus("Modifying file: " + fileNameSys + ". Edit content and save.", false);
        }

        System::Void btnDeleteFile_Click(System::Object^ sender, System::EventArgs^ e) {
            if (listBoxVFSFiles->SelectedItem == nullptr) {
                MessageBox::Show("Please select a file to delete.", "Selection Error", MessageBoxButtons::OK, MessageBoxIcon::Warning);
                ShowStatus("Select a file to delete.", true);
                return;
            }

            String^ selectedItemSys = listBoxVFSFiles->SelectedItem->ToString();
            int parenIndex = selectedItemSys->LastIndexOf(" (");
            if (parenIndex == -1) { /* ... error ... */ return; }
            String^ fileNameSys = selectedItemSys->Substring(0, parenIndex);

            System::Windows::Forms::DialogResult confirmResult = MessageBox::Show(
                "Are you sure you want to delete '" + fileNameSys + "'?",
                "Confirm Delete",
                MessageBoxButtons::YesNo,
                MessageBoxIcon::Question);

            if (confirmResult == System::Windows::Forms::DialogResult::Yes) {
                std::string fileNameStd = msclr::interop::marshal_as<std::string>(fileNameSys);
                std::string resultStd = vfs->deleteFile(fileNameStd);
                String^ resultSys = msclr::interop::marshal_as<String^>(resultStd);

                bool errorOccurred = resultStd.rfind("Error:", 0) == 0;
                MessageBoxIcon icon = errorOccurred ? MessageBoxIcon::Error : MessageBoxIcon::Information;
                MessageBox::Show(resultSys, "Delete File", MessageBoxButtons::OK, icon);
                ShowStatus(resultSys, errorOccurred);

                if (!errorOccurred) {
                    RefreshFileList();
                    ClearEditor(); // clear editor after delete
                }
            }
            else {
                ShowStatus("Delete cancelled for " + fileNameSys, false);
            }
        }

        System::Void btnCopyFromWin_Click(System::Object^ sender, System::EventArgs^ e) {
            OpenFileDialog^ openFileDialog = gcnew OpenFileDialog();
            openFileDialog->Filter = "All files (*.*)|*.*|Text files (*.txt)|*.txt";
            openFileDialog->Title = "Select a File to Copy into VFS";

            if (openFileDialog->ShowDialog() == System::Windows::Forms::DialogResult::OK) {
                String^ windowsPathSys = openFileDialog->FileName;

                // ask user for VFS filename or use original
                String^ vfsFileNameSys = Path::GetFileName(windowsPathSys); // default to original name

                std::string windowsPathStd = msclr::interop::marshal_as<std::string>(windowsPathSys);
                std::string vfsFileNameStd = msclr::interop::marshal_as<std::string>(vfsFileNameSys);

                std::string resultStd = vfs->copyFromWindows(windowsPathStd, vfsFileNameStd);
                String^ resultSys = msclr::interop::marshal_as<String^>(resultStd);

                bool errorOccurred = resultStd.rfind("Error:", 0) == 0;
                MessageBoxIcon icon = errorOccurred ? MessageBoxIcon::Error : MessageBoxIcon::Information;
                MessageBox::Show(resultSys, "Copy from Windows", MessageBoxButtons::OK, icon);
                ShowStatus(resultSys, errorOccurred);

                if (!errorOccurred) {
                    RefreshFileList();
                }
            }
        }

        System::Void btnCopyToWin_Click(System::Object^ sender, System::EventArgs^ e) {
            if (listBoxVFSFiles->SelectedItem == nullptr) {
                MessageBox::Show("Please select a VFS file to copy.", "Selection Error", MessageBoxButtons::OK, MessageBoxIcon::Warning);
                ShowStatus("Select VFS file to copy.", true);
                return;
            }

            String^ selectedItemSys = listBoxVFSFiles->SelectedItem->ToString();
            int parenIndex = selectedItemSys->LastIndexOf(" (");
            if (parenIndex == -1) { /* ... error ... */ return; }
            String^ vfsFileNameSys = selectedItemSys->Substring(0, parenIndex);

            SaveFileDialog^ saveFileDialog = gcnew SaveFileDialog();
            saveFileDialog->FileName = vfsFileNameSys; // default to VFS name
            saveFileDialog->Filter = "All files (*.*)|*.*|Text files (*.txt)|*.txt";
            saveFileDialog->Title = "Select Destination to Copy VFS File";

            if (saveFileDialog->ShowDialog() == System::Windows::Forms::DialogResult::OK) {
                String^ windowsPathSys = saveFileDialog->FileName;
                std::string vfsFileNameStd = msclr::interop::marshal_as<std::string>(vfsFileNameSys);
                std::string windowsPathStd = msclr::interop::marshal_as<std::string>(windowsPathSys);

                std::string resultStd = vfs->copyToWindows(vfsFileNameStd, windowsPathStd);
                String^ resultSys = msclr::interop::marshal_as<String^>(resultStd);

                bool errorOccurred = resultStd.rfind("Error:", 0) == 0;
                MessageBoxIcon icon = errorOccurred ? MessageBoxIcon::Error : MessageBoxIcon::Information;
                MessageBox::Show(resultSys, "Copy to Windows", MessageBoxButtons::OK, icon);
                ShowStatus(resultSys, errorOccurred);
            }
        }

        System::Void listBoxVFSFiles_SelectedIndexChanged(System::Object^ sender, System::EventArgs^ e) {
            if (listBoxVFSFiles->Focused && listBoxVFSFiles->SelectedItem != nullptr) { 
                btnViewFile_Click(sender, e);
            }
            else if (listBoxVFSFiles->SelectedItem == nullptr) {
                ClearEditor();
                groupBoxEditor->Text = "Editor / Viewer";
            }
        }
    };
}