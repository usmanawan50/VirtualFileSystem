#include "VirtualFileSystem.h"
#define NOMINMAX
#include <cstdio>    
using namespace std;

// ctor
VirtualFileSystem::VirtualFileSystem() : disk(DISK_SIZE) {
    size_t blockCount = DATA_SPACE_SIZE / BLOCK_SIZE;
    for(size_t i = 0; i < blockCount; ++i) 
        freeBlocks.push(i);
}

// class methods
double VirtualFileSystem::usagePercent() const {
    size_t totalDataBlockSpace = DATA_SPACE_SIZE / BLOCK_SIZE; // total blocks available for data
    size_t availableBlocks = freeBlocks.size() + freedBlocks.size();
    size_t usedBlocks = totalDataBlockSpace - availableBlocks;
    return static_cast<double>(usedBlocks) / totalDataBlockSpace; // percentage of data blocks used
}

vector<size_t> VirtualFileSystem::allocateBlocks(size_t bytes) {
    size_t blocksNeeded = (bytes + BLOCK_SIZE - 1) / BLOCK_SIZE;
    vector<size_t> alloc;

    while(!freedBlocks.empty() && alloc.size() < blocksNeeded) {
        alloc.push_back(freedBlocks.top());
        freedBlocks.pop();
    }
    while(!freeBlocks.empty() && alloc.size() < blocksNeeded) {
        alloc.push_back(freeBlocks.front());
        freeBlocks.pop();
    }
    if(alloc.size() < blocksNeeded) {
        for(auto i : alloc) freedBlocks.push(i); // Rollback
        alloc.clear();
    }
    return alloc;
}

void VirtualFileSystem::freeAllocatedBlocks(const vector<size_t>& blocks) {
    for(auto i : blocks) {
        freedBlocks.push(i);
    }
}

void VirtualFileSystem::writeToDisk(const vector<size_t>& blocks, const string& data) {
    size_t pos = 0;
    for(auto b : blocks) {
        size_t toWrite = std::min(static_cast<size_t>(BLOCK_SIZE), data.size() - pos);
        size_t offset = DIRECTORY_SPACE_SIZE + METADATA_SPACE_SIZE + b * BLOCK_SIZE;
        if(offset + toWrite > disk.size()) {
            return;
        }
        memcpy(&disk[offset], data.data() + pos, toWrite);
        pos += toWrite;
        if(pos >= data.size()) break; 
    }
}

string VirtualFileSystem::readFromDisk(const FileEntry& f) const {
    string out;
    out.reserve(f.getSize());
    size_t remaining = f.getSize();
    for(auto b : f.getBlocksRef()) { // use getBlocksRef for efficiency
        size_t toRead = min(static_cast<size_t>(BLOCK_SIZE), remaining);
        size_t offset = DIRECTORY_SPACE_SIZE + METADATA_SPACE_SIZE + b * BLOCK_SIZE;
        if(offset + toRead > disk.size()) {
            // error: trying to read beyond disk bounds
            return "Error: Disk read out of bounds.";
        }
        out.append(&disk[offset], toRead);
        remaining -= toRead;
        if(remaining == 0) break;
    }
    return out;
}

string VirtualFileSystem::createFile(const string& name, const string& data) {
    if(directory.size() >= MAX_DIRECTORY_ENTRIES) {
        return "Error: Maximum directory entries reached.";
    }
    if(usagePercent() > 0.95) { 
        return "Error: Disk space nearly full (>95% used). Delete files first.";
    }
    if(name.empty() || name.find_first_of("\\/:*?\"<>|") != std::string::npos) {
        return "Error: Invalid filename. Contains illegal characters or is empty.";
    }
    if(directoryIndex.count(name)) {
        return "Error: File already exists.";
    }

    auto blocks = allocateBlocks(data.size());
    if(blocks.empty() && data.size() > 0) { // only an error if data exists but no blocks
        return "Error: Not enough space to create file.";
    }
    if(data.size() == 0 && blocks.empty()) { // special case for empty file.
    }


    writeToDisk(blocks, data);
    directory.emplace_back(FileEntry{ name, blocks, data.size() });
    directoryIndex[name] = std::prev(directory.end());
    return "File '" + name + "' created successfully.";
}

vector<std::pair<string, size_t>> VirtualFileSystem::listFiles() const {
    vector<pair<string, size_t>> files;
    for(const auto& entry : directory) {
        files.push_back({ entry.getName(), entry.getSize() });
    }
    return files;
}

vector<string> VirtualFileSystem::getFileNames() const {
    vector<string> names;
    for(const auto& entry : directory) {
        names.push_back(entry.getName());
    }
    return names;
}

std::string VirtualFileSystem::viewFile(const std::string& fileName) {
    auto it = directoryIndex.find(fileName);
    if(it == directoryIndex.end()) {
        return "Error: File not found.";
    }
    return readFromDisk(*(it->second));
}

string VirtualFileSystem::copyFromWindows(const string& windowsPath, string vfsFileName) {
    if(directory.size() >= MAX_DIRECTORY_ENTRIES) {
        return "Error: Maximum directory entries reached.";
    }
    if(usagePercent() > 0.95) {
        return "Error: Disk space nearly full (>95% used).";
    }

    ifstream in(windowsPath, ios::binary | ios::ate); // open at end to get size
    if(!in) 
        return "Error: Cannot open Windows source file: " + windowsPath;
    
    streamsize size = in.tellg();
    in.seekg(0, ios::beg); // go back to the beginning to read
    string data(size, '\0');
    if(!in.read(&data[0], size)) 
        return "Error: Could not read from Windows source file.";
    
    in.close();

    if(vfsFileName.empty()) { // If no VFS name provided, extract from path
        size_t pos = windowsPath.find_last_of("/\\");
        vfsFileName = (pos == string::npos) ? windowsPath : windowsPath.substr(pos + 1);
    }

    if(vfsFileName.empty() || vfsFileName.find_first_of("\\/:*?\"<>|") != string::npos) 
        return "Error: Invalid VFS filename derived. Contains illegal characters or is empty.";
    
    if(directoryIndex.count(vfsFileName)) 
        return "Error: File '" + vfsFileName + "' already exists in VFS.";
    
    auto blocks = allocateBlocks(data.size());
    if(blocks.empty() && data.size() > 0) 
        return "Error: Not enough space in VFS for file '" + vfsFileName + "'.";
    
    if (data.size() == 0 && blocks.empty()) {}
        
    writeToDisk(blocks, data);
    directory.emplace_back(FileEntry{ vfsFileName, blocks, data.size() });
    directoryIndex[vfsFileName] = prev(directory.end());
    return "File '" + vfsFileName + "' copied from Windows successfully.";
}

string VirtualFileSystem::copyToWindows(const string& vfsFileName, const string& windowsPath) {
    auto it = directoryIndex.find(vfsFileName);
    if(it == directoryIndex.end()) 
        return "Error: VFS File '" + vfsFileName + "' not found.";

    ofstream out(windowsPath, ios::binary);
    if(!out) 
        return "Error: Cannot open/create Windows destination file: " + windowsPath;

    string data = readFromDisk(*(it->second));
    if(data.rfind("Error:", 0) == 0) // check if readFromDisk returned an error
        return data; // Propagate the error
    
    out.write(data.data(), data.size());
    out.close();
    return "File '" + vfsFileName + "' copied to '" + windowsPath + "' successfully.";
}

string VirtualFileSystem::modifyFile(const string& fileName, const string& newData) {
    auto it = directoryIndex.find(fileName);
    if(it == directoryIndex.end()) 
        return "Error: File '" + fileName + "' not found for modification.";
    

    FileEntry& entry = *(it->second); // get a reference to modify
    string oldData; 

    // free old blocks
    freeAllocatedBlocks(entry.getBlocksRef()); // use reference to avoid copy

    // Allocate new blocks
    auto newBlocks = allocateBlocks(newData.size());

    if(newBlocks.empty() && newData.size() > 0) {
        entry.getBlocksRefNonConst().clear(); // no blocks now
        entry.setSize(0);
        return "Error: Not enough space for new content. File content cleared. Original blocks freed.";
    }
    if(newData.size() == 0 && newBlocks.empty()) {}

    writeToDisk(newBlocks, newData);
    entry.getBlocksRefNonConst() = std::move(newBlocks); // update blocks in file entry
    entry.setSize(newData.size());              // update size in file entry

    return "File '" + fileName + "' modified successfully.";
}

string VirtualFileSystem::deleteFile(const string& fileName) {
    auto it = directoryIndex.find(fileName);
    if (it == directoryIndex.end()) {
        return "Error: File '" + fileName + "' not found for deletion.";
    }

    freeAllocatedBlocks(it->second->getBlocksRef());
    directory.erase(it->second); // erase from list
    directoryIndex.erase(it);    // erase from map

    return "File '" + fileName + "' deleted successfully.";
}

