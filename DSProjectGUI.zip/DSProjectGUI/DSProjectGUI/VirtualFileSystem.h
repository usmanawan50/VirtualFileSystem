#pragma once 

#include <iostream>
#include <vector>
#include <list>
#include <queue>
#include <stack>
#include <map>
#include <string>
#include <fstream>
#include <algorithm>
#include <limits>
#include <cstring> 
#include <stdexcept> 
using namespace std;

// disk specifications 
static const int DISK_SIZE = 10 * 1024 * 1024;        // 10 MB total disk size
static const int DIRECTORY_SPACE_SIZE = 1 * 1024 * 1024; // 1 MB for file entries
static const int METADATA_SPACE_SIZE = 1 * 1024 * 1024;  // 1 MB for free blocks metadata
static const int DATA_SPACE_SIZE = 8 * 1024 * 1024;      // 8 MB for file data
static const int BLOCK_SIZE = 1024;                      // 1 KB basic block unit
static const int MAX_DIRECTORY_ENTRIES = DIRECTORY_SPACE_SIZE / 500; // 500 B per file entry

static const char* TEMP_CREATE = "temp_create.txt";
static const char* TEMP_MODIFY = "temp_modify.txt";

class FileEntry {
private:
    string name;
    vector<size_t> blocks;
    size_t size = 0;
public:
    FileEntry() = default;
    FileEntry(const string& name, const vector<size_t>& blocks, size_t size)
              : name(name), blocks(blocks), size(size) {}

    string getName() const { return name; }
    vector<size_t> getBlocks() const { return blocks; }
    const vector<size_t>& getBlocksRef() const { return blocks; } 
    std::vector<size_t>& getBlocksRefNonConst() { return blocks; } 
    size_t getSize() const { return size; }
    void setSize(size_t newSize) { size = newSize; }
};

class VirtualFileSystem {
private:
    vector<char> disk;
    queue<size_t> freeBlocks;
    stack<size_t> freedBlocks;
    list<FileEntry> directory;
    map<std::string, std::list<FileEntry>::iterator> directoryIndex;

public:
    VirtualFileSystem(); // ctor

    double usagePercent() const;
    vector<size_t> allocateBlocks(size_t bytes);
    void freeAllocatedBlocks(const vector<size_t>& blocks);
    void writeToDisk(const vector<size_t>& blocks, const string& data);
    string readFromDisk(const FileEntry& f) const;

    // class methods
    string createFile(const string& name, const string& data);
    vector<std::pair<std::string, size_t>> listFiles() const;
    string viewFile(const std::string& fileName);
    string copyFromWindows(const std::string& windowsPath, std::string vfsFileName);
    string copyToWindows(const std::string& vfsFileName, const std::string& windowsPath);
    string modifyFile(const std::string& fileName, const std::string& newData);
    string deleteFile(const std::string& fileName);
    vector<std::string> getFileNames() const;
};